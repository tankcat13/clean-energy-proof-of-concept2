extends Node2D
var stored_energy:int = 0
var stored_energyMAX:int = 0
var demand:int = 0
var energy_production:int = 0
var coal_stored:int = 0
var nuclear_fuel_stored:int = 0
var nuclear_waste_stored:int = 0
var coal_storedMAX:int = 0
var nuclear_fuel_storedMAX:int = 0
var nuclear_waste_storedMAX:int = 0
var pollution_level:int = 0
var avalible_population:int = 0
var total_population:int = 0
var dock_count:int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Current_Population.text = "Current Population: " + str(total_population)
	$Avalable_population.text = "Avalible Population: " + str(avalible_population)
	$storedpower.text = "Stored Power: " + str(stored_energy)  + "/" + str(stored_energyMAX)
	$powerdemand.text = "Power Demand: " + str(demand)
	$storednuclear.text = "Nuclear Fuel Stored: " + str(nuclear_fuel_stored) + "/" + str(nuclear_fuel_storedMAX)
	$storedwaste.text = "Nuclear Waste Stored: " + str(nuclear_waste_stored) + "/" + str(nuclear_waste_storedMAX)
	$storedcoal.text = "Coal Stored: " + str(coal_stored) + "/" + str(coal_storedMAX)
	$powersupply.text = "Power supplied: " + str(energy_production)
	$Pollution.text = "Pollution Level: " + str(pollution_level)
