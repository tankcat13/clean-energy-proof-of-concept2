extends Sprite2D
var gtg = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	visible = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass



func _on_area_2d_body_entered(body: Node2D) -> void:
	gtg = true # Replace with function body.

func _on_timer_timeout() -> void:
	if !gtg:
		queue_free()
	visible = true # Replace with function body.
