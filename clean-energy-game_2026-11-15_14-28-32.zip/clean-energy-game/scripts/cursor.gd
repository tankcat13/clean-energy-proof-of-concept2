extends Area2D
var last_position = Vector2.ZERO
@export var city:PackedScene
@export var dock:PackedScene
var dectectsea = false
var detectground = false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	last_position = position
	if $Timer.is_stopped():
		if Input.is_action_pressed("ui_down"):
			position.y += 16
			$Timer.start()
		if Input.is_action_pressed("ui_up"):
			position.y += -16
			$Timer.start()
		if Input.is_action_pressed("ui_left"):
			position.x += -16
			$Timer.start()
		if Input.is_action_pressed("ui_right"):
			position.x += 16
			$Timer.start()
	@warning_ignore("narrowing_conversion")
	position.y = clampi(position.y,8,248)
	@warning_ignore("narrowing_conversion")
	position.x = clampi(position.x,-40,520)
	if Input.is_action_just_pressed("ui_accept"):		
		if !has_overlapping_bodies() && !$underthesea.has_overlapping_bodies():
			var placecity = city.instantiate()
			placecity.position = global_position
			add_sibling(placecity)
	if Input.is_action_just_pressed("ui_cancel"):
		if $underthesea.has_overlapping_bodies() && !has_overlapping_bodies():
			var placedock = dock.instantiate()
			placedock.position = global_position
			add_sibling(placedock)
func _on_body_entered(body: Node2D) -> void:
	detectground = false # Replace with function body.


func _on_body_exited(body: Node2D) -> void:
	detectground = true # Replace with function body.


func _on_underthesea_body_entered(body: Node2D) -> void:
	dectectsea = true # Replace with function body.


func _on_underthesea_body_exited(body: Node2D) -> void:
	dectectsea = false # Replace with function body.
