extends Sprite2D
var growtimer = 20
var buildtimer = 2
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	get_parent().avalible_population += -1


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if buildtimer == 0:
		modulate = Color.WHITE
	if growtimer == 0:
		pass

func tick() -> void:
	if !buildtimer == 0:
		buildtimer += -1
	else:
		growtimer += -1
